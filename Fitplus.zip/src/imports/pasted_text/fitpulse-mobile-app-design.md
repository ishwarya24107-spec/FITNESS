Design a complete mobile fitness app called "FitPulse" in dark theme.
Frame size: 390 x 844px (iPhone 14 Pro) for each screen.

DESIGN STYLE:
- Dark theme. Background: #0A0F0D, Card surfaces: #141A17
- Primary accent: #1D9E75 (teal green)
- Bright accent: #39EEAD (for glows and highlights)
- Text primary: #FFFFFF, Text secondary: #8FA89F
- Streak/warning color: #EF9F27
- Font: DM Sans (body), Plus Jakarta Sans (headings)
- Border radius: 16px for cards, 26px for buttons (pill shape)
- Button height: 52px minimum
- Screen padding: 20px left and right
- All icons: outline style only

---

SCREEN 1 — SPLASH SCREEN
- Full dark background (#0A0F0D)
- Centered layout
- A rounded square logo icon (teal bolt/lightning icon inside)
- App name "FitPulse" in bold below the logo
- Tagline: "Your journey starts now" in muted text
- Subtle loading indicator at the bottom

---

SCREEN 2 — WELCOME SCREEN
- Full dark background
- Large fitness illustration at the top (abstract runner or body in motion)
- Bold headline: "Train Smarter. Feel Better."
- Subtext: "Personalized workouts designed around your goals."
- Primary CTA button (full width, pill, teal): "Get Started"
- Secondary link text below: "Already have an account? Log In"
- Both CTAs in the bottom thumb zone

---

SCREEN 3 — ONBOARDING SLIDE 1 of 3
- "Skip" text button top right
- Dot pagination: filled dot, empty dot, empty dot
- Large illustration: goal/target visual
- Headline: "Set Your Goals"
- Description: "Tell us what you want to achieve and we'll build the perfect plan for you."
- Full-width teal pill button: "Next →"

---

SCREEN 4 — ONBOARDING SLIDE 2 of 3
- Same layout as slide 1
- Dots: filled, filled, empty
- Illustration: progress chart / streak calendar
- Headline: "Track Your Progress"
- Description: "Watch your streaks grow and celebrate every milestone along the way."
- Button: "Next →"

---

SCREEN 5 — ONBOARDING SLIDE 3 of 3
- Dots: all filled
- Illustration: personalized plan / AI visual
- Headline: "Workouts Made for You"
- Description: "Every plan is tailored to your level, goals, and schedule."
- Button changes to: "Let's Begin →" (same teal pill style)

---

SCREEN 6 — SIGNUP / LOGIN SCREEN
- Tab toggle at top: "Sign Up" (active, white text) | "Log In" (muted)
- Toggle has a dark card background with active tab highlighted
- Social login buttons (full width, dark card with border):
  → "Continue with Google" (Google icon)
  → "Continue with Apple" (Apple icon)
- Divider: — OR —
- Input fields (dark, rounded, 52px height):
  → Email address
  → Password (with show/hide eye icon)
- Primary CTA: "Create Account" (teal pill button)
- "Forgot Password?" link in muted text below

---

SCREEN 7 — PROFILE SETUP SCREEN
- Progress bar at top: Step 1 of 3 (33% filled in teal)
- Heading: "Tell us about yourself"
- Avatar circle with camera icon (optional, centered)
- Input fields:
  → Full Name (text input)
  → Age (stepper: minus button, number, plus button)
  → Weight (input with kg/lbs toggle)
  → Height (input with cm/ft toggle)
- Primary CTA: "Continue →"

---

SCREEN 8 — FITNESS GOAL SELECTION
- Progress bar: Step 2 of 3 (66% teal)
- Heading: "What's your primary goal?"
- 4 goal cards in a 2x2 grid, each card:
  → Dark card (#141A17), 16px radius
  → Icon (teal, outline) + Goal name (bold) + short description
  → Goals: Lose Weight (flame icon), Build Muscle (barbell icon),
    Stay Active (run icon), Improve Flexibility (yoga icon)
  → Selected state: teal border (#1D9E75), teal icon
- Primary CTA: "Next →" (disabled until one card is selected)

---

SCREEN 9 — WORKOUT LEVEL SELECTION
- Progress bar: Step 3 of 3 (100% teal)
- Heading: "What's your fitness level?"
- 3 vertically stacked level cards, each full width:
  → Icon + Level name (bold) + description text
  → Beginner: seedling icon — "Just starting out, new to workouts"
  → Intermediate: flame icon — "Some experience, ready to push harder"
  → Advanced: trophy icon — "Consistent training, high intensity"
  → Selected state: teal left border or full teal outline
- CTA: "Create My Plan ✓" (exciting, motivational copy)

---

SCREEN 10 — HOME DASHBOARD
- Top bar: Greeting "Good morning, Priya 👋" + streak badge (🔥 5-day streak, amber)
- Stats row (3 dark metric cards): Calories Burned | Current Streak | Total Workouts
- Section: "Today's Workout"
  → Large dark card with workout name "Full Body Beginner"
  → Details: 25 min · 8 exercises · Beginner
  → Teal pill CTA inside card: "Start Workout →"
- Section: "Recommended for You" (horizontal scroll row of smaller workout cards)
- Fixed bottom navigation bar (dark, slight top border):
  → Home (active, teal icon) | Workouts | Progress | Profile
  → Icons: outline style, label below each

---

COMPONENT LIBRARY TO CREATE:
- Button/Primary (teal pill, 52px, default + disabled + pressed states)
- Input Field (dark, rounded, label + placeholder + error state)
- Goal Card (default + selected variant)
- Level Card (default + selected variant)
- Stat Widget (icon + number + label)
- Progress Bar (steps 1/3, 2/3, 3/3)
- Bottom Navigation Bar (4 icons, active state)
- Social Login Button (Google + Apple variants)
- Onboarding Dot Indicator (3 dots, active state)

---

AUTO LAYOUT RULES:
- Apply Auto Layout to every frame
- Horizontal padding: 20px on all screens
- Vertical gap between sections: 24px
- Gap between elements inside sections: 12px
- All buttons: fill width (hug content vertically)
- Cards: fill width, hug height

---

PROTOTYPE CONNECTIONS:
Splash → Welcome (after 2 sec delay)
Welcome "Get Started" → Onboarding Slide 1 (Push, 300ms, Ease Out)
Onboarding Next buttons → next slide (Slide Left)
Onboarding Skip → Signup Screen
Slide 3 "Let's Begin" → Signup Screen (Push)
Signup "Create Account" → Profile Setup (Push)
Profile "Continue" → Goal Selection (Push)
Goal "Next" → Level Selection (Push)
Level "Create My Plan" → Home Dashboard (Dissolve, 400ms)