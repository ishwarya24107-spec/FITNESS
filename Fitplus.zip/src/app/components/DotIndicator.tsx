import React from 'react';

interface DotIndicatorProps {
  total: number;
  current: number;
}

export function DotIndicator({ total, current }: DotIndicatorProps) {
  return (
    <div className="flex gap-2 justify-center">
      {Array.from({ length: total }).map((_, index) => (
        <div
          key={index}
          className={`h-2 rounded-full transition-all duration-300 ${
            index < current
              ? 'w-8 bg-[#1D9E75]'
              : 'w-2 bg-[#8FA89F]/30'
          }`}
        />
      ))}
    </div>
  );
}
