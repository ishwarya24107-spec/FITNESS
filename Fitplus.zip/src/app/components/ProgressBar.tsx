import React from 'react';

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
}

export function ProgressBar({ currentStep, totalSteps }: ProgressBarProps) {
  const percentage = (currentStep / totalSteps) * 100;

  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm text-[#8FA89F]">
          Step {currentStep} of {totalSteps}
        </span>
        <span className="text-sm text-[#8FA89F]">{Math.round(percentage)}%</span>
      </div>
      <div className="w-full h-2 bg-[#141A17] rounded-full overflow-hidden">
        <div
          className="h-full bg-[#1D9E75] transition-all duration-300 ease-out"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
