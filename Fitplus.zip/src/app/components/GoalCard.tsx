import React from 'react';
import { LucideIcon } from 'lucide-react';

interface GoalCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  selected: boolean;
  onClick: () => void;
}

export function GoalCard({ icon: Icon, title, description, selected, onClick }: GoalCardProps) {
  return (
    <button
      onClick={onClick}
      className={`w-full p-6 bg-[#141A17] rounded-2xl text-left transition-all duration-200 ${
        selected
          ? 'border-2 border-[#1D9E75]'
          : 'border-2 border-transparent hover:border-white/10'
      }`}
    >
      <Icon
        size={32}
        className={`mb-3 ${selected ? 'text-[#1D9E75]' : 'text-[#8FA89F]'}`}
        strokeWidth={1.5}
      />
      <h4 className="text-white mb-1">{title}</h4>
      <p className="text-sm text-[#8FA89F]">{description}</p>
    </button>
  );
}
