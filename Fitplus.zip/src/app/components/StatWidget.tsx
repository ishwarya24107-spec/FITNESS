import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatWidgetProps {
  icon: LucideIcon;
  value: string | number;
  label: string;
}

export function StatWidget({ icon: Icon, value, label }: StatWidgetProps) {
  return (
    <div className="flex-1 bg-[#141A17] rounded-2xl p-4 text-center">
      <Icon size={20} className="text-[#1D9E75] mx-auto mb-2" strokeWidth={1.5} />
      <div className="text-2xl font-bold text-white mb-1">{value}</div>
      <div className="text-xs text-[#8FA89F]">{label}</div>
    </div>
  );
}
