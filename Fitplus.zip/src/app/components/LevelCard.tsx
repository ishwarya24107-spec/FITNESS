import React from 'react';
import { LucideIcon } from 'lucide-react';

interface LevelCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  selected: boolean;
  onClick: () => void;
}

export function LevelCard({ icon: Icon, title, description, selected, onClick }: LevelCardProps) {
  return (
    <button
      onClick={onClick}
      className={`w-full p-5 bg-[#141A17] rounded-2xl text-left flex items-center gap-4 transition-all duration-200 ${
        selected
          ? 'border-l-4 border-[#1D9E75] shadow-lg shadow-[#1D9E75]/20'
          : 'border-l-4 border-transparent hover:border-white/10'
      }`}
    >
      <Icon
        size={28}
        className={`${selected ? 'text-[#1D9E75]' : 'text-[#8FA89F]'}`}
        strokeWidth={1.5}
      />
      <div className="flex-1">
        <h4 className="text-white mb-0.5">{title}</h4>
        <p className="text-sm text-[#8FA89F]">{description}</p>
      </div>
    </button>
  );
}
