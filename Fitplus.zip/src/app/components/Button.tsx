import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost';
  children: React.ReactNode;
}

export function Button({ variant = 'primary', children, className = '', disabled, ...props }: ButtonProps) {
  const baseStyles = "w-full h-[52px] rounded-[26px] font-semibold transition-all duration-200";
  
  const variantStyles = {
    primary: disabled 
      ? "bg-[#1D9E75]/30 text-white/50 cursor-not-allowed"
      : "bg-[#1D9E75] text-white hover:bg-[#168a65] active:bg-[#137556]",
    secondary: "bg-[#141A17] text-white border border-white/10 hover:bg-[#1a211e]",
    ghost: "bg-transparent text-[#8FA89F] hover:text-white"
  };

  return (
    <button
      className={`${baseStyles} ${variantStyles[variant]} ${className}`}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  );
}
