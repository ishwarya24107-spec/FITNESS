import React from 'react';
import { Home, Dumbbell, TrendingUp, User } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router';

export function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { icon: Home, label: 'Home', path: '/dashboard' },
    { icon: Dumbbell, label: 'Workouts', path: '/workouts' },
    { icon: TrendingUp, label: 'Progress', path: '/progress' },
    { icon: User, label: 'Profile', path: '/profile' }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#0A0F0D] border-t border-white/10 px-5 pt-3 pb-6 max-w-[390px] mx-auto">
      <div className="flex justify-around items-center">
        {navItems.map(({ icon: Icon, label, path }) => {
          const isActive = location.pathname === path;
          return (
            <button
              key={path}
              onClick={() => navigate(path)}
              className="flex flex-col items-center gap-1 min-w-[60px]"
            >
              <Icon
                size={24}
                className={isActive ? 'text-[#1D9E75]' : 'text-[#8FA89F]'}
                strokeWidth={1.5}
              />
              <span className={`text-xs ${isActive ? 'text-[#1D9E75]' : 'text-[#8FA89F]'}`}>
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
