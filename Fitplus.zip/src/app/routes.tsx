import { createBrowserRouter } from 'react-router';
import { SplashScreen } from './screens/SplashScreen';
import { WelcomeScreen } from './screens/WelcomeScreen';
import { OnboardingScreen } from './screens/OnboardingScreen';
import { AuthScreen } from './screens/AuthScreen';
import { ProfileSetupScreen } from './screens/ProfileSetupScreen';
import { GoalSelectionScreen } from './screens/GoalSelectionScreen';
import { LevelSelectionScreen } from './screens/LevelSelectionScreen';
import { DashboardScreen } from './screens/DashboardScreen';
import { WorkoutsScreen } from './screens/WorkoutsScreen';
import { ProgressScreen } from './screens/ProgressScreen';
import { ProfileScreen } from './screens/ProfileScreen';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: SplashScreen
  },
  {
    path: '/welcome',
    Component: WelcomeScreen
  },
  {
    path: '/onboarding/:slide',
    Component: OnboardingScreen
  },
  {
    path: '/auth',
    Component: AuthScreen
  },
  {
    path: '/profile-setup',
    Component: ProfileSetupScreen
  },
  {
    path: '/goal-selection',
    Component: GoalSelectionScreen
  },
  {
    path: '/level-selection',
    Component: LevelSelectionScreen
  },
  {
    path: '/dashboard',
    Component: DashboardScreen
  },
  {
    path: '/workouts',
    Component: WorkoutsScreen
  },
  {
    path: '/progress',
    Component: ProgressScreen
  },
  {
    path: '/profile',
    Component: ProfileScreen
  }
]);
