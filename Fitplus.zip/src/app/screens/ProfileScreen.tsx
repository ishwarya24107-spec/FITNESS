import React from 'react';
import { BottomNav } from '../components/BottomNav';

export function ProfileScreen() {
  return (
    <div className="min-h-screen bg-[#0A0F0D] pb-24">
      <div className="px-5 py-8">
        <h2 className="text-white mb-4">Profile</h2>
        <p className="text-[#8FA89F]">Manage your account settings</p>
      </div>
      <BottomNav />
    </div>
  );
}
