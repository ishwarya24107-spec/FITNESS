import React from 'react';
import { useNavigate, useParams } from 'react-router';
import { Button } from '../components/Button';
import { DotIndicator } from '../components/DotIndicator';
import { Target, TrendingUp, Sparkles } from 'lucide-react';

const slides = [
  {
    icon: Target,
    title: 'Set Your Goals',
    description: 'Tell us what you want to achieve and we\'ll build the perfect plan for you.'
  },
  {
    icon: TrendingUp,
    title: 'Track Your Progress',
    description: 'Watch your streaks grow and celebrate every milestone along the way.'
  },
  {
    icon: Sparkles,
    title: 'Workouts Made for You',
    description: 'Every plan is tailored to your level, goals, and schedule.'
  }
];

export function OnboardingScreen() {
  const navigate = useNavigate();
  const { slide } = useParams();
  const currentSlide = parseInt(slide || '1');
  const slideData = slides[currentSlide - 1];
  const Icon = slideData.icon;

  const handleNext = () => {
    if (currentSlide < 3) {
      navigate(`/onboarding/${currentSlide + 1}`);
    } else {
      navigate('/auth');
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0F0D] flex flex-col px-5 py-12">
      {/* Skip Button */}
      <div className="flex justify-end mb-8">
        <button
          onClick={() => navigate('/auth')}
          className="text-[#8FA89F] hover:text-white transition-colors"
        >
          Skip
        </button>
      </div>

      {/* Dot Indicator */}
      <div className="mb-12">
        <DotIndicator total={3} current={currentSlide} />
      </div>

      {/* Illustration */}
      <div className="flex-1 flex items-center justify-center mb-8">
        <div className="relative">
          <div className="w-64 h-64 bg-gradient-to-br from-[#1D9E75]/20 to-[#39EEAD]/20 rounded-full flex items-center justify-center">
            <Icon size={100} className="text-[#1D9E75]" strokeWidth={1.5} />
          </div>
          <div className="absolute -top-4 -right-4 w-20 h-20 bg-[#39EEAD]/30 rounded-full blur-xl"></div>
          <div className="absolute -bottom-4 -left-4 w-24 h-24 bg-[#1D9E75]/30 rounded-full blur-xl"></div>
        </div>
      </div>

      {/* Content */}
      <div className="space-y-6 mb-12">
        <div className="text-center space-y-3">
          <h1 className="text-white">{slideData.title}</h1>
          <p className="text-[#8FA89F] text-lg">
            {slideData.description}
          </p>
        </div>
      </div>

      {/* CTA */}
      <Button onClick={handleNext}>
        {currentSlide === 3 ? "Let's Begin →" : "Next →"}
      </Button>
    </div>
  );
}
