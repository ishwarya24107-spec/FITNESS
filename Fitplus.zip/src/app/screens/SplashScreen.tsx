import React, { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Zap } from 'lucide-react';

export function SplashScreen() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/welcome');
    }, 2000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-[#0A0F0D] flex flex-col items-center justify-center px-5">
      <div className="flex flex-col items-center">
        {/* Logo */}
        <div className="w-20 h-20 bg-gradient-to-br from-[#1D9E75] to-[#39EEAD] rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-[#1D9E75]/30">
          <Zap size={40} className="text-white fill-white" />
        </div>
        
        {/* App Name */}
        <h1 className="text-white mb-2">FitPulse</h1>
        
        {/* Tagline */}
        <p className="text-[#8FA89F]">Your journey starts now</p>
      </div>

      {/* Loading Indicator */}
      <div className="absolute bottom-20">
        <div className="flex gap-1">
          <div className="w-2 h-2 bg-[#1D9E75] rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
          <div className="w-2 h-2 bg-[#1D9E75] rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
          <div className="w-2 h-2 bg-[#1D9E75] rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
        </div>
      </div>
    </div>
  );
}
