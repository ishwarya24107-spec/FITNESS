import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { ProgressBar } from '../components/ProgressBar';
import { Camera, Minus, Plus } from 'lucide-react';

export function ProfileSetupScreen() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [age, setAge] = useState(25);
  const [weight, setWeight] = useState(70);
  const [height, setHeight] = useState(170);
  const [weightUnit, setWeightUnit] = useState<'kg' | 'lbs'>('kg');
  const [heightUnit, setHeightUnit] = useState<'cm' | 'ft'>('cm');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/goal-selection');
  };

  return (
    <div className="min-h-screen bg-[#0A0F0D] flex flex-col px-5 py-12">
      {/* Progress Bar */}
      <div className="mb-8">
        <ProgressBar currentStep={1} totalSteps={3} />
      </div>

      {/* Heading */}
      <h2 className="text-white mb-8">Tell us about yourself</h2>

      {/* Avatar Upload */}
      <div className="flex justify-center mb-8">
        <button className="w-24 h-24 rounded-full bg-[#141A17] border-2 border-dashed border-white/20 flex items-center justify-center hover:border-[#1D9E75] transition-colors">
          <Camera size={32} className="text-[#8FA89F]" strokeWidth={1.5} />
        </button>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-6 flex-1">
        <Input
          label="Full Name"
          placeholder="Enter your name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />

        {/* Age Stepper */}
        <div>
          <label className="block text-white mb-2">Age</label>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setAge(Math.max(15, age - 1))}
              className="w-12 h-12 bg-[#141A17] rounded-xl flex items-center justify-center text-white hover:bg-[#1a211e] transition-colors"
            >
              <Minus size={20} />
            </button>
            <div className="flex-1 h-[52px] bg-[#141A17] rounded-2xl flex items-center justify-center text-white text-xl font-semibold">
              {age}
            </div>
            <button
              type="button"
              onClick={() => setAge(Math.min(100, age + 1))}
              className="w-12 h-12 bg-[#141A17] rounded-xl flex items-center justify-center text-white hover:bg-[#1a211e] transition-colors"
            >
              <Plus size={20} />
            </button>
          </div>
        </div>

        {/* Weight */}
        <div>
          <label className="block text-white mb-2">Weight</label>
          <div className="flex gap-3">
            <input
              type="number"
              value={weight}
              onChange={(e) => setWeight(Number(e.target.value))}
              className="flex-1 h-[52px] bg-[#141A17] rounded-2xl px-4 text-white border border-white/10 focus:border-[#1D9E75] focus:outline-none"
              required
            />
            <div className="bg-[#141A17] rounded-2xl p-1 flex">
              <button
                type="button"
                onClick={() => setWeightUnit('kg')}
                className={`px-4 py-2 rounded-xl transition-all ${
                  weightUnit === 'kg' ? 'bg-[#1D9E75] text-white' : 'text-[#8FA89F]'
                }`}
              >
                kg
              </button>
              <button
                type="button"
                onClick={() => setWeightUnit('lbs')}
                className={`px-4 py-2 rounded-xl transition-all ${
                  weightUnit === 'lbs' ? 'bg-[#1D9E75] text-white' : 'text-[#8FA89F]'
                }`}
              >
                lbs
              </button>
            </div>
          </div>
        </div>

        {/* Height */}
        <div>
          <label className="block text-white mb-2">Height</label>
          <div className="flex gap-3">
            <input
              type="number"
              value={height}
              onChange={(e) => setHeight(Number(e.target.value))}
              className="flex-1 h-[52px] bg-[#141A17] rounded-2xl px-4 text-white border border-white/10 focus:border-[#1D9E75] focus:outline-none"
              required
            />
            <div className="bg-[#141A17] rounded-2xl p-1 flex">
              <button
                type="button"
                onClick={() => setHeightUnit('cm')}
                className={`px-4 py-2 rounded-xl transition-all ${
                  heightUnit === 'cm' ? 'bg-[#1D9E75] text-white' : 'text-[#8FA89F]'
                }`}
              >
                cm
              </button>
              <button
                type="button"
                onClick={() => setHeightUnit('ft')}
                className={`px-4 py-2 rounded-xl transition-all ${
                  heightUnit === 'ft' ? 'bg-[#1D9E75] text-white' : 'text-[#8FA89F]'
                }`}
              >
                ft
              </button>
            </div>
          </div>
        </div>

        <div className="pt-4">
          <Button type="submit">Continue →</Button>
        </div>
      </form>
    </div>
  );
}
