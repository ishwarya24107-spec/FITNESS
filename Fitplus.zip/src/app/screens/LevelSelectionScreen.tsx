import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/Button';
import { LevelCard } from '../components/LevelCard';
import { ProgressBar } from '../components/ProgressBar';
import { Sprout, Flame, Trophy } from 'lucide-react';

const levels = [
  {
    id: 'beginner',
    icon: Sprout,
    title: 'Beginner',
    description: 'Just starting out, new to workouts'
  },
  {
    id: 'intermediate',
    icon: Flame,
    title: 'Intermediate',
    description: 'Some experience, ready to push harder'
  },
  {
    id: 'advanced',
    icon: Trophy,
    title: 'Advanced',
    description: 'Consistent training, high intensity'
  }
];

export function LevelSelectionScreen() {
  const navigate = useNavigate();
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);

  const handleContinue = () => {
    if (selectedLevel) {
      navigate('/dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0F0D] flex flex-col px-5 py-12">
      {/* Progress Bar */}
      <div className="mb-8">
        <ProgressBar currentStep={3} totalSteps={3} />
      </div>

      {/* Heading */}
      <h2 className="text-white mb-8">What's your fitness level?</h2>

      {/* Level Cards */}
      <div className="space-y-4 mb-8 flex-1">
        {levels.map((level) => (
          <LevelCard
            key={level.id}
            icon={level.icon}
            title={level.title}
            description={level.description}
            selected={selectedLevel === level.id}
            onClick={() => setSelectedLevel(level.id)}
          />
        ))}
      </div>

      {/* CTA */}
      <Button disabled={!selectedLevel} onClick={handleContinue}>
        Create My Plan ✓
      </Button>
    </div>
  );
}
