import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { SocialButton } from '../components/SocialButton';

export function AuthScreen() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'signup' | 'login'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeTab === 'signup') {
      navigate('/profile-setup');
    } else {
      navigate('/dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0F0D] flex flex-col px-5 py-12">
      {/* Tab Toggle */}
      <div className="bg-[#141A17] rounded-2xl p-1 flex mb-8">
        <button
          onClick={() => setActiveTab('signup')}
          className={`flex-1 py-3 rounded-xl font-semibold transition-all ${
            activeTab === 'signup'
              ? 'bg-[#1D9E75] text-white'
              : 'text-[#8FA89F]'
          }`}
        >
          Sign Up
        </button>
        <button
          onClick={() => setActiveTab('login')}
          className={`flex-1 py-3 rounded-xl font-semibold transition-all ${
            activeTab === 'login'
              ? 'bg-[#1D9E75] text-white'
              : 'text-[#8FA89F]'
          }`}
        >
          Log In
        </button>
      </div>

      {/* Social Login */}
      <div className="space-y-3 mb-6">
        <SocialButton provider="google" />
        <SocialButton provider="apple" />
      </div>

      {/* Divider */}
      <div className="flex items-center gap-4 mb-6">
        <div className="flex-1 h-px bg-white/10"></div>
        <span className="text-[#8FA89F] text-sm">OR</span>
        <div className="flex-1 h-px bg-white/10"></div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-4 flex-1">
        <Input
          type="email"
          placeholder="Email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <Input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          showPasswordToggle
          required
        />
        
        <div className="pt-2">
          <Button type="submit">
            {activeTab === 'signup' ? 'Create Account' : 'Log In'}
          </Button>
        </div>

        {activeTab === 'login' && (
          <button
            type="button"
            className="w-full text-[#8FA89F] hover:text-white transition-colors text-sm"
          >
            Forgot Password?
          </button>
        )}
      </form>
    </div>
  );
}
