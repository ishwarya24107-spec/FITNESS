import React from 'react';
import { StatWidget } from '../components/StatWidget';
import { BottomNav } from '../components/BottomNav';
import { Flame, Calendar, Zap, Clock, ListChecks } from 'lucide-react';
import { Button } from '../components/Button';

const workouts = [
  {
    id: 1,
    name: 'Upper Body Strength',
    duration: '30 min',
    exercises: 10,
    level: 'Intermediate'
  },
  {
    id: 2,
    name: 'Cardio Blast',
    duration: '20 min',
    exercises: 6,
    level: 'Beginner'
  },
  {
    id: 3,
    name: 'Core & Abs',
    duration: '15 min',
    exercises: 8,
    level: 'Beginner'
  }
];

export function DashboardScreen() {
  return (
    <div className="min-h-screen bg-[#0A0F0D] pb-24">
      <div className="px-5 py-8">
        {/* Greeting & Streak */}
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="text-white mb-1">Good morning, Priya 👋</h2>
            <p className="text-[#8FA89F]">Ready to crush your goals?</p>
          </div>
          <div className="bg-gradient-to-r from-[#EF9F27] to-[#f5b24a] px-4 py-2 rounded-full flex items-center gap-2">
            <Flame size={16} className="text-white" />
            <span className="text-white font-semibold">5 days</span>
          </div>
        </div>

        {/* Stats Row */}
        <div className="flex gap-3 mb-8">
          <StatWidget icon={Flame} value="1,247" label="Calories" />
          <StatWidget icon={Calendar} value="5" label="Streak" />
          <StatWidget icon={Zap} value="12" label="Workouts" />
        </div>

        {/* Today's Workout */}
        <div className="mb-8">
          <h3 className="text-white mb-4">Today's Workout</h3>
          <div className="bg-gradient-to-br from-[#141A17] to-[#1a2621] rounded-2xl p-6 border border-[#1D9E75]/20">
            <h3 className="text-white mb-3">Full Body Beginner</h3>
            <div className="flex items-center gap-4 text-[#8FA89F] text-sm mb-4">
              <div className="flex items-center gap-1">
                <Clock size={16} />
                <span>25 min</span>
              </div>
              <div className="flex items-center gap-1">
                <ListChecks size={16} />
                <span>8 exercises</span>
              </div>
              <div className="flex items-center gap-1">
                <Zap size={16} />
                <span>Beginner</span>
              </div>
            </div>
            <Button>Start Workout →</Button>
          </div>
        </div>

        {/* Recommended Workouts */}
        <div>
          <h3 className="text-white mb-4">Recommended for You</h3>
          <div className="flex gap-4 overflow-x-auto pb-2 -mx-5 px-5 scrollbar-hide">
            {workouts.map((workout) => (
              <div
                key={workout.id}
                className="min-w-[280px] bg-[#141A17] rounded-2xl p-5 border border-white/10"
              >
                <h4 className="text-white mb-3">{workout.name}</h4>
                <div className="flex items-center gap-3 text-[#8FA89F] text-sm mb-4">
                  <div className="flex items-center gap-1">
                    <Clock size={14} />
                    <span>{workout.duration}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <ListChecks size={14} />
                    <span>{workout.exercises} exercises</span>
                  </div>
                </div>
                <div className="inline-block px-3 py-1 bg-[#1D9E75]/20 text-[#39EEAD] text-xs rounded-full">
                  {workout.level}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
