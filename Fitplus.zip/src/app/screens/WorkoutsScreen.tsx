import React from 'react';
import { BottomNav } from '../components/BottomNav';

export function WorkoutsScreen() {
  return (
    <div className="min-h-screen bg-[#0A0F0D] pb-24">
      <div className="px-5 py-8">
        <h2 className="text-white mb-4">Workouts</h2>
        <p className="text-[#8FA89F]">Browse all available workouts</p>
      </div>
      <BottomNav />
    </div>
  );
}
