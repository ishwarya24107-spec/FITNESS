import React from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/Button';
import { Activity } from 'lucide-react';

export function WelcomeScreen() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#0A0F0D] flex flex-col px-5 py-12">
      {/* Illustration */}
      <div className="flex-1 flex items-center justify-center mb-8">
        <div className="relative">
          <div className="w-64 h-64 bg-gradient-to-br from-[#1D9E75]/20 to-[#39EEAD]/20 rounded-full flex items-center justify-center">
            <Activity size={120} className="text-[#1D9E75]" strokeWidth={1.5} />
          </div>
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#39EEAD]/20 rounded-full blur-2xl"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-[#1D9E75]/20 rounded-full blur-2xl"></div>
        </div>
      </div>

      {/* Content */}
      <div className="space-y-6 mb-8">
        <div className="text-center space-y-3">
          <h1 className="text-white">Train Smarter. Feel Better.</h1>
          <p className="text-[#8FA89F] text-lg">
            Personalized workouts designed around your goals.
          </p>
        </div>
      </div>

      {/* CTAs */}
      <div className="space-y-4">
        <Button onClick={() => navigate('/onboarding/1')}>
          Get Started
        </Button>
        <button
          onClick={() => navigate('/auth')}
          className="w-full text-[#8FA89F] hover:text-white transition-colors"
        >
          Already have an account? <span className="text-[#1D9E75]">Log In</span>
        </button>
      </div>
    </div>
  );
}
