import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/Button';
import { GoalCard } from '../components/GoalCard';
import { ProgressBar } from '../components/ProgressBar';
import { Flame, Dumbbell, Activity, Flower2 } from 'lucide-react';

const goals = [
  {
    id: 'lose-weight',
    icon: Flame,
    title: 'Lose Weight',
    description: 'Burn calories and shed pounds'
  },
  {
    id: 'build-muscle',
    icon: Dumbbell,
    title: 'Build Muscle',
    description: 'Gain strength and mass'
  },
  {
    id: 'stay-active',
    icon: Activity,
    title: 'Stay Active',
    description: 'Maintain a healthy lifestyle'
  },
  {
    id: 'flexibility',
    icon: Flower2,
    title: 'Improve Flexibility',
    description: 'Enhance mobility and balance'
  }
];

export function GoalSelectionScreen() {
  const navigate = useNavigate();
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);

  const handleContinue = () => {
    if (selectedGoal) {
      navigate('/level-selection');
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0F0D] flex flex-col px-5 py-12">
      {/* Progress Bar */}
      <div className="mb-8">
        <ProgressBar currentStep={2} totalSteps={3} />
      </div>

      {/* Heading */}
      <h2 className="text-white mb-8">What's your primary goal?</h2>

      {/* Goal Grid */}
      <div className="grid grid-cols-2 gap-4 mb-8">
        {goals.map((goal) => (
          <GoalCard
            key={goal.id}
            icon={goal.icon}
            title={goal.title}
            description={goal.description}
            selected={selectedGoal === goal.id}
            onClick={() => setSelectedGoal(goal.id)}
          />
        ))}
      </div>

      {/* CTA */}
      <div className="mt-auto">
        <Button disabled={!selectedGoal} onClick={handleContinue}>
          Next →
        </Button>
      </div>
    </div>
  );
}
