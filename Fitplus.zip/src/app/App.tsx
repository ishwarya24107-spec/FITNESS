import { RouterProvider } from 'react-router';
import { router } from './routes';

export default function App() {
  return (
    <div className="min-h-screen bg-[#0A0F0D] flex items-center justify-center">
      <div className="w-full max-w-[390px] min-h-screen bg-[#0A0F0D] relative">
        <RouterProvider router={router} />
      </div>
    </div>
  );
}
