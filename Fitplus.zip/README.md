
  # Fitplus

  This is a code bundle for Fitplus. The original project is available at https://www.figma.com/design/UTG8TVsfIUkq7Y1Z4MqTht/Fitplus.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  